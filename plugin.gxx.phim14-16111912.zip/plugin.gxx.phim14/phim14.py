#-*- coding:utf-8 -*-
from lib.gxx import *

def home():
    addItem({"menu":"watchedlist","name":"Phim đã xem"})
    addItem({"menu":"watchlater","name":"Danh sách yêu thích"})
    addItem({"menu":"search","name":"Tìm kiếm"})
    addItem({"menu":"listmovie","name":"Phim mới cập nhật", "url":"http://m.phim14.net"})

def listmovie():
    content = BeautifulSoup(web(url))
    for k in content.findAll("a", {"class":"content-items"}):
            addItem({"menu":"listep", "name": k.get("title"), "url":k.get('href'), "icon":k.img.get("src")})
def listep():
    content = BeautifulSoup(web(url))
    u= content.findAll("li", {"style":"max-height:70px;"})[0].a.get("href")
    c=BeautifulSoup(web(u))
    for link in c.findAll("a"):
        try:
            if "xem-phim" in link.get("href"): 
                addItem({"menu":"watch", "name":"Tập "+link.contents[0]+" | "+name,"url":link.get("href"), "icon":icon, "isFolder":0})
        except: None

def watch():
    content = BeautifulSoup(web(url))
    link = re.compile('{link:"(.+?)"').findall(str(content))[0]
    phpurl="http://player62.phim14.net/mobile88gkphp108m/plugins/gkpluginsphp.php"
    data = {'link' : link, 'age'  : '10'}
    
    header = { 
        'User-Agent'		: 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0',
        'Accept'   	    	: 'application/json, text/javascript, */*; q=0.01',
        'Cookie'			: this_addon.getSetting("cookies"),
        'Referer'			: url,
        'X-Requested-With'	: 'XMLHttpRequest'
        }

    content = web(phpurl,data, header)
    content=json.loads(content); #log(content)
    #content =content["link"][0]["link"]
    #playVideo(content,name)
    q=[]
    l=[]
    for v in content["link"]:
        q.append(v["label"])
        l.append(v["link"])
    playVideo(l[select(q)],name)

if submenu != "":
    pass
elif menu == "":
    home()
elif menu == "listmovie":
    listmovie()
elif menu == "listep":
    listep()
elif menu == "search":
    keyword = search()
    url = "http://phim14.net/search/"+re.sub('\s+','+',keyword)+".html"
    content = BeautifulSoup(web(url,"",2))
    for nod in content.findAll("div", {"class":"inner"}):
      try:  addItem({"menu":"listep","name":nod.a.get("title"),"url":re.sub("phim14","m.phim14",nod.a.get("href")),"icon":nod.a.img.get("src")})
      except: None
elif menu == "watch":
    watch()

    
end()
#1
#2
#3