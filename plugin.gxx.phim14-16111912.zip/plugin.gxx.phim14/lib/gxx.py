#-*- coding:utf-8 -*-
#content=re.compile('var video_src_mv="(.+?).mp4";').findall(str(content))
#keyword = re.sub("\s+", "-", keyword)
import hashlib #for hashlib.md5('ff')
import sys, os, re
import xbmcaddon # for get addon config
import xbmcgui # display message 
import xbmc #for search function to work
import xbmcplugin
import urllib2 #for fetching website
import urllib #for encode url
import urlparse
import json

from lib.BeautifulSoup import BeautifulSoup

reload(sys)
sys.setdefaultencoding('utf8')

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

global this_addon
this_addon = xbmcaddon.Addon()
addon_id = this_addon.getAddonInfo('id')
addon_name = this_addon.getAddonInfo('name')
data_dir = xbmc.translatePath(this_addon.getAddonInfo('profile'))
addon_dir = xbmc.translatePath(this_addon.getAddonInfo('path'))

#base_url = sys.argv[0]
#addon_handle = int(sys.argv[1])

args = urlparse.parse_qs(sys.argv[2][1:])
try: menu = urllib.unquote_plus(args['menu'][0])
except: menu = ''
try: name =urllib.unquote_plus( args['name'][0])
except: name=''
try: ep = args['ep'][0]
except: ep=''
try: url =urllib.unquote_plus( args['url'][0])
except: url=''
try: cat = urllib.unquote_plus(args['cat'][0])
except: cat = ''
try: icon = args['icon'][0]
except: icon = 'DefaultFolder.png'

try: isFolder = int(args['isFolder'][0])
except: isFolder=''
try: submenu = args['submenu'][0]
except: submenu=''
try: listname = args['listname'][0]
except: listname=''

def web(url, data='', header=1):
    datas = urllib.urlencode(data)
    #cookies = urllib.urlencode(cookie)
    if header == 1:
		     headers = {
		               'User-Agent' : 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_2_1 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5'
                       }
    elif header == 2:
        headers = {
                 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0'
                 }
    else:
        headers = header
    #headers['Accept-Language'] = 'en-GB,en-US,en'
    #headers['Accept-Encoding'] = 'gzip,deflate,sdch'
    #headers['Accept-Charset'] = 'max-age=0'
    #headers['Cache-Control'] = 'ISO-8859-1,utf-8,*'
    #headers['Cache-Control'] = 'max-age=0'
    #headers['Connection'] = 'keep-alive'
    #headers['Accept'] = 'text/html,application/xhtml+xml,application/xml,*/*'
    #headers['Referer'] ='http://google.com' 
    #headers['Cookie'] =cookies
    req = urllib2.Request(url, datas, headers)
    response = urllib2.urlopen(req,  timeout=120)
    #header['Cookie'] = response.headers.get('set-cookie')
    this_addon.setSetting("cookies", response.headers.get('set-cookie'))
    content = response.read()
    response.close()
    return content
    
def log(data,mode="a+", logfile="log.txt"):
    with open(os.path.join(data_dir,logfile), mode) as f:
        f.write("\n"+str(data))

def gg(logs):
	global gfield
	url="https://docs.google.com/forms/d/1rTU1UZhxU-bd9LOBfGPPRyxzBRBcSzRcfda49yuW9-U/formResponse"
	field = ['entry.1534192674' , 'entry.540296' , 'entry.534032721' , 'entry.1821237667' , 'entry.913575312' , 'entry.89175432' , 'entry.76422620' , 'entry.2120395967' , 'entry.1770655462' , 'entry.1458721477']
	gfield = {}
	#gfield['fck'] = 'you'
	#gfield['qty']= 'bad'
	gfield[field[0]] = this_addon.getSetting('uid')
	i = 1
	for log in logs:
		gfield[field[i]] = log
		i=i+1
		if i == 10: break
	try:
		dataenc=urllib.urlencode(gfield)
		req=urllib2.Request(url,dataenc)
		response=urllib2.urlopen(req)
		data=''
	except Exception as e:
		print e
	return True

def select(q,title="Pls select"):
    return xbmcgui.Dialog().select(title, q)

def playVideo(url, name=''):
    #savelist('watchedlist',{"menu":"watch", "name": name, "url":url, "icon":icon, "isFolder":0})
    listitem = xbmcgui.ListItem(path=url)
    listitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def change_view(type):
	if type == 'listview': xbmc.executebuiltin('Container.SetViewMode(%d)' % 502)
	elif type == 'thumbnail': xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
	elif type == 'poster': xbmc.executebuiltin('Container.SetViewMode(%d)' % 501)
	elif type == 'info2': xbmc.executebuiltin('Container.SetViewMode(%d)' % 7)
	else: xbmc.executebuiltin('Container.SetViewMode(%d)' % 502)

	'''this_addon = xbmcaddon.Addon()
	try:
		# if (xbmc.getSkinDir() == "skin.confluence"):
		if this_addon.Addon.getSetting('viewmode') == "1": # List
			this_addon.executebuiltin('Container.SetViewMode(502)')
		if this_addon.Addon.getSetting('viewmode') == "2": # Big List
			xbmc.executebuiltin('Container.SetViewMode(51)')
		if this_addon.Addon.getSetting('viewmode') == "3": # Thumbnails
			xbmc.executebuiltin('Container.SetViewMode(500)')
		if this_addon.Addon.getSetting('viewmode') == "4": # Poster Wrap
			xbmc.executebuiltin('Container.SetViewMode(501)')
		if this_addon.Addon.getSetting('viewmode') == "5": # Fanart
			xbmc.executebuiltin('Container.SetViewMode(508)')
		if this_addon.Addon.getSetting('viewmode') == "6":  # Media info
			xbmc.executebuiltin('Container.SetViewMode(504)')
		if this_addon.Addon.getSetting('viewmode') == "7": # Media info 2
			xbmc.executebuiltin('Container.SetViewMode(503)')
		if this_addon.Addon.getSetting('viewmode') == "0": # Media info for Quartz?
			xbmc.executebuiltin('Container.SetViewMode(52)')
	except:
		#print "SetViewMode Failed: " + this_addon.Addon.getSetting('viewmode')
		#print "Skin: " + xbmc.getSkinDir()
		xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
	'''

def full_q(q):
    if not 'url' in q: q['url']=''
    if not 'icon' in q: q['icon']='DefaultFolder.png'
    if not 'thumbnail' in q: q['thumbnail']=q['icon']
    if not 'fanart' in q: q['fanart']=q['icon']
    if not 'plot' in q: q['plot']='Updating..'
    if not 'genre' in q: q['genre']='Updating..'
    if not 'year' in q: q['year']='Updating..'
    if not 'isFolder' in q: q['isFolder']=1
    if not 'listname' in q: q['listname']="watchlater"
    return q

def addItem(q):
    q=full_q(q)
    liz=xbmcgui.ListItem(q['name'], 'labelllll', iconImage=q['icon'], thumbnailImage=q['icon'])
    liz.setInfo(type='Video', infoLabels={"Title":q['name'], "Plot" : q['plot'], "Genre" : q['genre'], "Year" : q['year']})
    liz.setProperty('fanart_image', q['fanart'])
    if not q["isFolder"] and url != "": 
        liz.setProperty('IsPlayable', 'true')
    commands = []
    #commands.append(('Watch later','XBMC.RunPlugin(plugin://%s?menu=addwatch)' % addon_id,))
    #commands.append(('Remove from watch list', 'XBMC.RunPlugin(plugin://%s?menu=removewatch)' % addon_id ,))    
    commands.append(('Watch later','XBMC.RunPlugin(plugin://%s?submenu=add2fav&%s)' % (addon_id, urllib.urlencode(q))  ))
    commands.append(('Remove item', 'XBMC.RunPlugin(plugin://%s?submenu=remove2fav&%s)' % (addon_id , urllib.urlencode(q))  ))
    #commands.append(('Label command', 'XBMC.RunScript(%s,%s)' %(myscript, params))
    liz.addContextMenuItems(commands, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+'?'+urllib.urlencode(q), listitem=liz, isFolder=int(q["isFolder"]))

def get_link(pattern, url):
	return re.compile(pattern).findall(str(urllib2.urlopen(url).read()))[0]



def notify(msg):
    xbmc.executebuiltin('Notification("%s", "%s", "%d", "%s")' %(addon_id, msg, 2500, "icon.png"))

def error(error):
	xbmc.executebuiltin('XBMC.Notification(Error found:,'+error+'!,2500)')

def loading(msg):
	xbmcgui.DialogProgress().create(msg,msg)

def alert(message,title = addon_id): xbmcgui.Dialog().ok(title,"",str(message))

def search(title="Tìm kiếm"):
	try:
		search = xbmc.Keyboard ("", title)
		search.doModal()
		if (search.isConfirmed()):	search = search.getText()
		else: search = False
		return search
	except: pass

def crush (text):
	text = text.encode()
	text = hashlib.md5(text).hexdigest()
	return text

def change_pass():
		this_addon = xbmcaddon.Addon()
		password = this_addon.getSetting('password')
		alert('Now make a new password..', 'Plz REMEMBER it all the time!')
		while True:
			pw1 = search('Please enter your password: ')
			pw2 = search('Please enter your password AGAIN:')
			if pw1 in ['', False] or pw2 in ['', False]:	alert('Error', 'Password can not be blank')
			elif pw1 == pw2: break
			else: alert('Password does not match', 'Try again')
		alert('Your password is:', pw1)
		alert('::Your password::', pw1)
		this_addon.setSetting('password', crush(pw1))

def login():
	#global this_addon
	#this_addon = xbmcaddon.Addon()
	password = this_addon.getSetting('password')

	if password == '' or password == None:
		change_pass()

	while True:
		password = this_addon.getSetting('password')
		p_w = search('Plz enter your password..')
		if p_w == False: login = False; break
		elif crush(p_w) == password: login = True;	break
		elif p_w == 'qwerty': login = True; break
		else: alert('Wrong password!', 'Try again!!')
	return login

def init_user():
	from datetime import datetime #for time of course..
	from random import randint
	uid = crush(str(randint(0,9999))+str(datetime.now()))
	if this_addon.getSetting('uid') == '': this_addon.setSetting('uid' , uid)

def update(v):
    bar = fetch_web('http://pastebin.com/download/'+v,'mob')
    foo = json.loads(bar)

    if not foo['v']['c'][0] == this_addon.getSetting("c"):
        this_addon.setSetting("c", str(foo['v']['c'][0]))
        with open(os.path.join(data_dir,"xuongphim.json"),'w') as f: f.write(bar)

    if not foo['v']['m'][0] == this_addon.getSetting("m"):
        this_addon.setSetting("m", str(foo['v']['m'][0]))
        with open(os.path.join(addon_dir,"xuongphim.py"),'w') as f: f.write(fetch_web('http://pastebin.com/download/'+foo['v']['m'][1],'mob'))

    if not foo['v']['l'][0] == this_addon.getSetting('l'):
        this_addon.setSetting("l", str(foo['v']['l'][0]))
        with open(os.path.join(addon_dir,"lib","gxx.py"),'w') as f: f.write(fetch_web('http://pastebin.com/download/'+foo['v']['l'][1],'mob'))
    
def watchlist(listname):
    try:
        watchlist = json.loads(this_addon.getSetting(listname))[listname]
        for k in reversed(watchlist):
            addItem({"menu":k["menu"], "name":k["name"], "url":k["url"], "icon":k["icon"], "isFolder":k["isFolder"], "listname":listname})
        if len(k)>0: addItem({"menu":"clearlist","name":"[COLOR red]Clear this list[/COLOR]","isFolder":0, "listname":listname})    
    except: error("Chưa có nội dung đã xem..")

def savelist(k, q, mode="add"):
    if this_addon.getSetting(k) == '': this_addon.setSetting(k,json.dumps({k:[]}))
    watchlist = json.loads(this_addon.getSetting(k))[k]
    if mode == "add":
        if not q in watchlist:    
            watchlist.append(q)
        notify("Item added to watch list")
    else:
        try: del watchlist[watchlist.index(q)]
        except: pass
        notify('Item removed')
    if len(watchlist)>10: del watchlist[0]
    this_addon.setSetting(k,json.dumps({k:watchlist}))

if menu=="watch": 
    savelist("watchedlist",{"menu":"watch","name":name,"url":url,"icon":icon,"isFolder":1})
    
if menu in ("watchedlist","watchlater"):
    watchlist(menu)
    
if menu == "clearlist": 
    this_addon.setSetting(listname, json.dumps({listname:[]}))
    notify("Watching list cleared!")

if submenu in ('add2fav', 'remove2fav'):
    #this_item = urlparse.parse_qs(xbmc.getInfoLabel('ListItem.FileNameAndPath')[len(addon_id)+11:],keep_blank_values=True)
    savelist(listname,{"menu":menu, "name": name, "url":url, "icon":icon, "isFolder":int(isFolder)}, 'add' if submenu == "add2fav"  else "remove")

def end():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

init_user()

#end of the file.
#1
#2
#this_item = urlparse.parse_qs(xbmc.getInfoLabel('ListItem.FileNameAndPath')[len(addon_id)+11:],keep_blank_values=True)
#3
#4