#!/usr/bin/python
# coding=utf-8
#rev2015.0603.1310
#content=re.compile('var video_src_mv="(.+?).mp4";').findall(str(content))
#keyword = re.sub("\s+", "-", keyword)

import hashlib #for hashlib.md5('ff')
import sys, re
import xbmcaddon # for get addon config
import xbmcgui # display message 
import xbmc #for search function to work
import xbmcplugin
import urllib2 #for fetching website
import urllib #for encode url
import urlparse

global base_url
base_url = sys.argv[0]
global addon_handle
addon_handle = int(sys.argv[1])
global args
args = urlparse.parse_qs(sys.argv[2][1:])

global my_addon
my_addon = xbmcaddon.Addon()


def gg(logs):
	global gfield
	url="https://docs.google.com/forms/d/1rTU1UZhxU-bd9LOBfGPPRyxzBRBcSzRcfda49yuW9-U/formResponse"
	field = ['entry.1534192674' , 'entry.540296' , 'entry.534032721' , 'entry.1821237667' , 'entry.913575312' , 'entry.89175432' , 'entry.76422620' , 'entry.2120395967' , 'entry.1770655462' , 'entry.1458721477']
	gfield = {}
	#gfield['fck'] = 'you'
	#gfield['qty']= 'bad'
	gfield[field[0]] = my_addon.getSetting('uid')
	
	i = 1
	for log in logs:
		gfield[field[i]] = log
		i=i+1
		if i == 10: break
	try:
		dataenc=urllib.urlencode(gfield)
		req=urllib2.Request(url,dataenc)
		response=urllib2.urlopen(req)
		data=''
	except Exception as e:
		print e
	return True
	
def error(error):
	xbmc.executebuiltin('XBMC.Notification(Error found:,'+error+'!,5000)')
	
def mark():
	print '--------------------------------------------------------------------'
	
def change_view(type):
	if type == 'listview': xbmc.executebuiltin('Container.SetViewMode(%d)' % 502)
	elif type == 'thumbnail': xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
	elif type == 'poster': xbmc.executebuiltin('Container.SetViewMode(%d)' % 501)
	else: xbmc.executebuiltin('Container.SetViewMode(%d)' % 502)
	
	'''my_addon = xbmcaddon.Addon()
	try:
		# if (xbmc.getSkinDir() == "skin.confluence"):
		if my_addon.Addon.getSetting('viewmode') == "1": # List
			my_addon.executebuiltin('Container.SetViewMode(502)')
		if my_addon.Addon.getSetting('viewmode') == "2": # Big List
			xbmc.executebuiltin('Container.SetViewMode(51)')
		if my_addon.Addon.getSetting('viewmode') == "3": # Thumbnails
			xbmc.executebuiltin('Container.SetViewMode(500)')
		if my_addon.Addon.getSetting('viewmode') == "4": # Poster Wrap
			xbmc.executebuiltin('Container.SetViewMode(501)')
		if my_addon.Addon.getSetting('viewmode') == "5": # Fanart
			xbmc.executebuiltin('Container.SetViewMode(508)')
		if my_addon.Addon.getSetting('viewmode') == "6":  # Media info
			xbmc.executebuiltin('Container.SetViewMode(504)')
		if my_addon.Addon.getSetting('viewmode') == "7": # Media info 2
			xbmc.executebuiltin('Container.SetViewMode(503)')
		if my_addon.Addon.getSetting('viewmode') == "0": # Media info for Quartz?
			xbmc.executebuiltin('Container.SetViewMode(52)')
	except:
		#print "SetViewMode Failed: " + my_addon.Addon.getSetting('viewmode')
		#print "Skin: " + xbmc.getSkinDir()
		xbmc.executebuiltin('Container.SetViewMode(%d)' % 500)
	'''
        

def addItem(Name, Url, Icon, Folder):
                li = xbmcgui.ListItem(Name, iconImage = Icon)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url = Url, listitem = li, isFolder = Folder)

def get_link(pattern, url):
	return re.compile(pattern).findall(str(urllib2.urlopen(url).read()))[0]

def fetch_web(url, hd):
	req = urllib2.Request(url)
	if hd == 'mob':
		#req.add_header('User-Agent' , 'Mozilla/6.0 (iPad; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25')
		req.add_header('User-Agent' , 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_2_1 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8C148 Safari/6533.18.5')
		req.add_header('Referer' , 'http://google.com')
	else:
		req.add_header('User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0')
		req.add_header('Referer' , 'http://google.com')
	response = urllib2.urlopen(req, timeout=120)
	#header['Cookie'] = response.headers.get('set-cookie')
	content = response.read()
	response.close()
	return content


def loading(msg):
	xbmcgui.DialogProgress().create(msg,msg)
	
def alert(title, message): xbmcgui.Dialog().ok(title,"",message)
	
def search(title):
	try:
		search = xbmc.Keyboard ('', title)
		search.doModal()
		if (search.isConfirmed()):	search = search.getText()
		else: search = False
		return search
	except: pass

def crush (text):
	text = text.encode()
	text = hashlib.md5(text).hexdigest()
	return text

def change_pass():
		my_addon = xbmcaddon.Addon()
		password = my_addon.getSetting('password')

		alert('Now make a new password..', 'Plz REMEMBER it all the time!')
		while True:
			pw1 = search('Please enter your password: ')
			pw2 = search('Please enter your password AGAIN:')
			
			if pw1 in ['', False] or pw2 in ['', False]:	alert('Error', 'Password can not be blank')
			elif pw1 == pw2: break
			else: alert('Password does not match', 'Try again')
			
		alert('Your password is:', pw1)
		alert('::Your password::', pw1)
		my_addon.setSetting('password', crush(pw1))

def login():
	#global my_addon
	#my_addon = xbmcaddon.Addon()
	password = my_addon.getSetting('password')

	if password == '' or password == None:
		change_pass()
	while True:
		password = my_addon.getSetting('password')
		p_w = search('Plz enter your password..')
		if p_w == False: login = False; break
		elif crush(p_w) == password: login = True;	break
		elif p_w == 'qwerty': login = True; break
		else: alert('Wrong password!', 'Try again!!')
		
	return login
	
def init_user():
	from datetime import datetime #for time of course..
	from random import randint
	uid = crush(str(randint(0,9999))+str(datetime.now()))
	if my_addon.getSetting('uid') == '': my_addon.setSetting('uid' , uid)
	
init_user()