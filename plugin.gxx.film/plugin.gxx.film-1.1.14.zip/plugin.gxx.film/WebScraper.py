#!/usr/bin/python
# coding=utf-8
#rev2015.0528.0857
from MyClass import *
import re
import xbmc
from BeautifulSoup import BeautifulSoup
base_url = sys.argv[0]
my_addon = xbmcaddon.Addon()

##############list cat
def list_cat(server):
	def get_cat_cached(server_cat):
		category = my_addon.getSetting(server_cat).split(',')
		for node in category:
			nod = node.split('|')
			addItem(str(nod[0]), str(nod[1]), 'DefaultFolder.png', 1)
			
	if server == 'biphim.com':
		print '####'

	elif server == 'phim14.net':
		addItem("Search..", base_url+"?action=list_movie&server="+server, "DefaultFolder.png", 1)
		addItem("New movie", base_url+"?action=list_movie&server="+server+"&url=http://phim14.net", "DefaultVideo.png", 1)

		if my_addon.getSetting('phim14_cat_1strun') == 'False': get_cat_cached('phim14_cat')
		else:
			content = BeautifulSoup(fetch_web('http://phim14.net', 'web'))
			phim14_cat = ''
			for node in content.findAll('ul' , {'class' : 'sub-menu'}):
				for nod in node.findAll('li'):
					addItem(nod.a.string, base_url+'?action=list_movie&server='+server+'&url='+nod.a.get('href'), 'DefaultFolder.png', 1)
					phim14_cat = phim14_cat+ nod.a.string+'|'+ base_url+'?action=list_movie&server='+server+'&url='+nod.a.get('href')+','
			my_addon.setSetting('phim14_cat' , phim14_cat[:-1])
			my_addon.setSetting('phim14_cat_1strun', 'False')

	elif server == 'xemphimhan.com':
		addItem("Search..", base_url+"?action=list_movie&server="+server, "DefaultFolder.png",1)
		addItem("New movie..", base_url+"?action=list_movie&server="+server+"&url=http://m.xemphimhan.com/page-1.html", "DefaultFolder.png",1)
		content = BeautifulSoup(fetch_web('http://m.xemphimhan.com','mob'))
		for node in content.findAll('li'):
			if '/phim-' in node.a.get('href'):
				addItem(node.a.get('title'), base_url+'?action=list_movie&server='+server+'&url=http://m.xemphimhan.com'+node.a.get('href')     ,'DefaultFolder.png', 1)

	elif server == 'xuongphim.tv':
		addItem('Search..' , base_url+'?action=list_movie&server='+server, 'DefaultVideo.png', 1)
		addItem("New movie", base_url+"?action=list_movie&server="+server+"&url=http://xuongphim.tv", "DefaultVideo.png", 1)
		if my_addon.getSetting('xuongphim_cat_1strun') == 'False': get_cat_cached('xuongphim_cat')
		else:
			content = BeautifulSoup(fetch_web('http://xuongphim.tv', 'mob'))
			xuongphim_cat = ''
			for node in content.findAll('li'):
				name = node.a.string
				link = node.a.get('href')
				logo = 'DefaultFolder.png'
				if link.startswith('/'): addItem(name, base_url+'?action=list_movie&server=xuongphim.tv&url=http://xuongphim.tv'+link , logo, 1)
				xuongphim_cat = xuongphim_cat+name+"|"+base_url+'?action=list_movie&server=xuongphim.tv&url=http://xuongphim.tv'+link+','
			my_addon.setSetting('xuongphim_cat' , xuongphim_cat[:-1])
			my_addon.setSetting('xuongphim_cat_1strun', 'False')			
			
	change_view('list')
##############list cat
##############list_movie
def list_movie(server, url):
 if server == 'phim14.net':
		if url == '':
			keyword = search('Nhap ten film can tim:')
			if keyword == False: url = 'http://phim14.net/'
			else: url = 'http://phim14.net/search/'+re.sub('\s', '-', keyword)+'.html'
		content = BeautifulSoup(fetch_web(url,'mobsa'))
		for node in content.findAll('div' , {'class' : 'img'}):
			addItem(node.a.get('title'), base_url+'?action=list_ep&server='+server+'&url='+node.a.get('href'), node.a.img.get('src'),1)
		for node in content.findAll('span' , {'class' : 'item'}):
			addItem('Trang: '+str(node.a.string), base_url+'?action=list_movie&server='+server+'&url='+node.a.get('href'), 'DefaultFolder.png', 1)	
		
 elif server == 'xemphimhan.com':
        if url == '':
                keyword = search('Nhap ten film can tim:')
                if keyword == False: url = 'http://m.xemphimhan.com/page-1.html'
                else:   url = 'http://m.xemphimhan.com/tim-kiem/'+re.sub("\s+" , "-" , keyword)
                               
        content = BeautifulSoup(fetch_web(url,'mob'))
        for node in content.findAll('div' , {'class' : 'content-items'}):
                link = node.a.get('href')
                name = node.a.get('title')
                logo = node.a.img.get('src')
                addItem(name, base_url+"?action=list_ep&server="+server+"&url="+link, logo, 1)
        for node in content.findAll('option'):
                link = node.get('value')
                name = node.contents[0]
                logo = 'DefaultFolder.png'
                addItem(name, base_url+"?action=list_movie&server="+server+"&url="+link, logo, 1)
 elif server == 'xuongphim.tv':
	if url == '':
		keyword=search('Nhap ten film can tim:')
		if keyword == False: url = 'http://xuongphim.tv/tim-kiem/-/trang-1.html'
		else: url = 'http://xuongphim.tv/tim-kiem/'+re.sub('\s+', '-', keyword)+'.html'
		content = BeautifulSoup(fetch_web(url,'web'))
		for node in content.findAll('div' , {'class' : 'tn-bxitem'}):
			link = 'http://xuongphim.tv'+node.a.get('href')
			logo = node.a.span.img.get('src')
			name = node.a.span.img.get('alt')
			addItem(name, base_url+"?action=list_ep&server="+server+"&url="+link, logo, 1)
		########pagination not worked yet.. because the stupidity of inconsistency in search and web & mobile view style
		'''for node in content.findAll('a' , {'rel' : 'nofollow'}):
			link = 'http://xuongphim.tv'+node.get('href')
			logo = 'DefaultVideo.png'
			name = 'Trang: '+str(node.string)
			addItem(name, base_url+"?action=list_movie&server="+server+"&url="+link, logo, 1)'''
		
	else:
		content = BeautifulSoup(fetch_web(url,'mob'))
		for node in content.findAll('div' , {'class' : 'content-items'}):
			link = node.a.get('href')
			name = node.a.get('title')
			logo = node.a.img.get('src')
			addItem(name, base_url+"?action=list_ep&server="+server+"&url=http://xuongphim.tv"+link, logo, 1)
		for node in content.findAll('option'):
			link = 'http://xuongphim.tv'+node.get('value')
			name = node.string
			logo = 'DefaultVideo.png'
			addItem(name, base_url+"?action=list_movie&server="+server+"&url="+link, logo, 1)
 change_view('poster')
#####################list_movie
#####################list_ep
def list_ep(server, url):
	if server == 'phim14.net':
		url = get_link('<a class="watch_button now" href="(.+?)">Xem phim</a>', url)
		content = BeautifulSoup(fetch_web(url,'mobss'))
		for node in content.findAll('a' , {'episode-type' : 'watch'}):
			addItem(node.get('title'), base_url+'?action=watch&server='+server+'&url='+re.sub('http://phim14.net', 'http://m.phim14.net', node.get('href'))+'?quality=720', 'DefaultVideo.png', 0)
	
	elif server =='xemphimhan.com':
		content = BeautifulSoup(fetch_web(url,'mob'))
		for node in content.findAll('a', {'class' : 'btn'}):
					    link = node.get('href')
					    name = 'Tap: '+str(node.contents[0])
					    logo = 'DefaultVideo.png'
					    addItem(name, base_url+"?action=watch&server="+server+"&url="+link, logo, 0)
                       
	elif server =='xuongphim.tv':
		content = BeautifulSoup(fetch_web(url,'mob'))
		for node in content.findAll('a' , {'class' : 'btn'}):
				name = 'Tap: '+str(node.string)
				link = 'http://xuongphim.tv'+node.get('href')
				logo = 'DefaultVideo.png'
				addItem(name, base_url+'?action=watch&server='+server+'&url='+link, logo, 0)

#####################list_ep 
#####################watch
def watch(server, urlz):
	content = fetch_web(urlz, 'mob')
	if server == 'phim14.net':
		print content
		url=re.compile('<source src="(.+?)" type="video/mp4"').findall(str(content))
		if url ==[]: url = re.compile('var video_src_mv= "(.+?)"').findall(str(content))
		if url == []:
			url = BeautifulSoup(content).iframe.get('src')
			if 'dailymotion' in url: url = get_daily(url)
			elif 'youtube.com' in url: url = get_youtube(url)
	
	elif server == 'xemphimhan.com':
		url=re.compile('var video_src_mv="(.+?)";').findall(str(content))
		if url == []:
			url = re.compile('" src="(.+?)" frameborder').findall(str(content))[0]
			if 'youtube' in url: url = get_youtube(url)
	
	elif server == 'xuongphim.tv':
		content = fetch_web(urlz, 'mob')
		print content
		url = re.compile('file: "(.+?)"').findall(str(content))
		if 'youtube' in url[0]: url = get_youtube(url[0])
		elif url == []:
			url = re.compile('proxy.link=(.+?)&').findall(str(content)) #get zing link
			if 'zing.vn' in url[0]: url = get_zing(url[0])
			
	
	loading('Please wait..')
	gg (['', base_url, 'video_link', server, url])
	try: 
		xbmc.Player().play(url[1])
	except Exception as e:
		try: 
			xbmc.Player().play(url[0])
		except Exception as e:
			error('Không thể kết nối tới server')
			gg ([e, base_url, action, server, urlz])

def get_youtube(url):
	from pafy import Pafy
	try: return [Pafy(url).getbest(preftype='mp4', ftypestrict=False).url]
	except Exception as e:
		alert('Error', 'The video on Youtube is deleted')
		gg ([e, base_url, action, server, url])
		
def get_daily(url):
	try:
		hd =  re.compile('"stream_h264_hd_url":"(.+?)","').findall(str(fetch_web(url,'mobs')))
		if hd == []:	return re.compile('"stream_h264_url":"(.+?)","').findall(str(fetch_web(url,'mobs')))
		else: return hd
	except Exception as e:
		gg ([e, base_url, action, server, url])
	
def get_zing(url):
	try:
		return re.compile('<source src="(.+?)"').findall(str(fetch_web(url, 'mob')))
	except Exception as e:
		gg ([e, base_url, action, server, url])
		
#####################watch 
