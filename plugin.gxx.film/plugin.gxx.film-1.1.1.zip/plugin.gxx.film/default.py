#!/usr/bin/python
# coding=utf8
 
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
 
import re
from BeautifulSoup import BeautifulSoup
from MyClass import *
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
 
xbmcplugin.setContent(addon_handle, 'movies')
 
def list_server():
        addItem('xemphimhan.com' , base_url+'?action=list_cat&server=xemphimhan.com' , 'DefaultFolder.png', 1)
        addItem('xuongphim.tv' , base_url+'?action=list_cat&server=xuongphim.tv' , 'DefaultFolder.png', 1)
        #addItem('biphim.com' , base_url+'?action=list_cat&server=biphim.com' , 'DefaultFolder.png',1)
 
def list_cat():
 if server == 'xemphimhan.com':
        addItem("Search..", base_url+"?action=list_movie&server="+server, "DefaultFolder.png",1)
        addItem("New movie..", base_url+"?action=list_movie&server="+server+"&url=http://m.xemphimhan.com/page-1.html", "DefaultFolder.png",1)
        content = BeautifulSoup(fetch_web('http://m.xemphimhan.com','mob'))
        for node in content.findAll('li'):
                if '/phim-' in node.a.get('href'):
                        addItem(node.a.get('title'), base_url+'?action=list_movie&server='+server+'&url=http://m.xemphimhan.com'+node.a.get('href')     ,'DefaultFolder.png', 1)
 elif server == 'xuongphim.tv':
	addItem('Search..' , base_url+'?action=list_movie&server='+server, 'DefaultVideo.png', 1)
        content = BeautifulSoup(fetch_web('http://xuongphim.tv', 'mob'))
        for node in content.findAll('li'):
                name = node.a.string
		link = node.a.get('href')
                logo = 'DefaultFolder.png'
                if link.startswith('/'): addItem(name, base_url+'?action=list_movie&server=xuongphim.tv&url=http://xuongphim.tv'+link , logo, 1)            
       
def list_movie():
 global url
 if server == 'xemphimhan.com':
        if url == '':
                keyword = search('Nhap ten film can tim:')
                if keyword == False: url = 'http://m.xemphimhan.com/page-1.html'
                else:   url = 'http://m.xemphimhan.com/tim-kiem/'+re.sub("\s+" , "-" , keyword)
                               
        content = BeautifulSoup(fetch_web(url,'mob'))
        for node in content.findAll('div' , {'class' : 'content-items'}):
                link = node.a.get('href')
                name = node.a.get('title')
                logo = node.a.img.get('src')
                addItem(name, base_url+"?action=list_ep&server="+server+"&url="+link, logo, 1)
        for node in content.findAll('option'):
                link = node.get('value')
                name = node.contents[0]
                logo = 'DefaultFolder.png'
                addItem(name, base_url+"?action=list_movie&server="+server+"&url="+link, logo, 1)
 if server == 'xuongphim.tv':
	if url == '':
		keyword=search('Nhap ten film can tim:')
		if keyword == False: url = 'http://xuongphim.tv/page-1.html'
		url = 'http://xuongphim.tv/page-5.html'
		# tim kiem dang bi loi else: url = 'http://xuongphim.tv/tim-kiem/'+re.sub('\s+', '-', keyword)
	content = BeautifulSoup(fetch_web(url,'mob'))
	for node in content.findAll('div' , {'class' : 'content-items'}):
		link = node.a.get('href')
		name = node.a.get('title')
		logo = node.a.img.get('src')
		addItem(name, base_url+"?action=list_ep&server="+server+"&url=http://xuongphim.tv"+link, logo, 1)
	for node in content.findAll('option'):
		link = 'http://xuongphim.tv'+node.get('value')
		name = node.string
		logo = 'DefaultVideo.png'
		addItem(name, base_url+"?action=list_movie&server="+server+"&url="+link, logo, 1)
def list_ep():
	content = BeautifulSoup(fetch_web(url,'mob'))
	if server =='xemphimhan.com':
                for node in content.findAll('a', {'class' : 'btn'}):
                        link = node.get('href')
                        name = 'Tap: '+str(node.contents[0])
                        logo = 'DefaultVideo.png'
                        addItem(name, base_url+"?action=watch&server="+server+"&url="+link, logo, 0)
                       
	elif server =='xuongphim.tv':
		for node in content.findAll('a' , {'class' : 'btn'}):
			name = 'Tap: '+node.string
			link = 'http://xuongphim.tv'+node.get('href')
			logo = 'DefaultVideo.png'
			addItem(name, base_url+'?action=watch&server='+server+'&url='+link, logo, 0)
 
def watch():
	global url
        content = urllib2.urlopen(url).read()
	loading('Please wait..')       
	if server == 'xemphimhan.com':
                url=re.compile('var video_src_mv="(.+?)";').findall(str(content))
                xbmc.Player().play(url[0])
	elif server == 'xuongphim.tv':
		url = re.compile('{file: "(.+?)"').findall(str(content))
		try: xbmc.Player().play(url[1])
		except: xbmc.Player().play(url[0])

 
try:    action = args['action'][0]
except: action = 'list_server'
try: server = args['server'][0]
except: server=''
try:    cat = args['cat'][0]
except: cat = ''
try:    url = args['url'][0]
except: url = ''
       
if action == 'list_server': list_server()
elif action == 'list_cat': list_cat()
elif action == 'list_movie': list_movie()
elif action == 'list_ep': list_ep()
elif action == 'watch': watch()
 
       
#############  
xbmcplugin.endOfDirectory(addon_handle)
##############
###########