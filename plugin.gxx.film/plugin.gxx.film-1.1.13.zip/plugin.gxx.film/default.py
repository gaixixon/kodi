#!/usr/bin/python
# coding=utf8
 
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
 
import re
from BeautifulSoup import BeautifulSoup
from MyClass import *
from WebScraper import *

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
 
xbmcplugin.setContent(addon_handle, 'movies')
my_addon=xbmcaddon.Addon(id='plugin.gxx.film')
icon_dir=my_addon.getAddonInfo('path')+'/resources/media/'

def list_server():
        addItem('phim14.net' , base_url+'?action=list_cat&server=phim14.net' , icon_dir+'phim14.png', 1)
        addItem('xuongphim.tv' , base_url+'?action=list_cat&server=xuongphim.tv' , icon_dir+'xuongphim.png', 1)
        addItem('xemphimhan.com' , base_url+'?action=list_cat&server=xemphimhan.com' , 'DefaultFolder.png', 1)
        #addItem('biphim.com' , base_url+'?action=list_cat&server=biphim.com' , 'DefaultFolder.png',1)
	change_view('thumbnail')

 
try:    action = args['action'][0]
except: action = 'list_server'
try: server = args['server'][0]
except: server=''
try:    cat = args['cat'][0]
except: cat = ''
try:    url = args['url'][0]
except: url = ''
       

if action == 'list_server': list_server()
elif action == 'list_cat': list_cat(server)
elif action == 'list_movie': list_movie(server, url)
elif action == 'list_ep': list_ep(server, url)
elif action == 'watch': watch(server, url)
 
       
#############  
xbmcplugin.endOfDirectory(addon_handle)
##############
###########
